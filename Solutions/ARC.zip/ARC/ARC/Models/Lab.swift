//
//  Lab.swift
//  ARC
//
//  Created by Alex Paul on 12/9/19.
//  Copyright © 2019 Alex Paul. All rights reserved.
//

import Foundation

struct Lab {
  var name: String
  var unit: String
}
