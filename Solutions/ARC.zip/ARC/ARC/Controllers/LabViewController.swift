//
//  LabViewController.swift
//  ARC
//
//  Created by Alex Paul on 12/9/19.
//  Copyright © 2019 Alex Paul. All rights reserved.
//

import UIKit

class LabViewController: UIViewController {
  var labs = Array(repeating: Lab(name: "Recursion Lab", unit: "Unit 4"), count: 25)
  
  // requiring self in closures is a way for Swift
  // to remind us that capturins self is a strong reference
  // and can lead to memory leaks
  
  // should we use a capture list [weak self]
  // or [unowned self]
  // weak self is used when the object reference could be nil
  // unowned self when both objects will be deallocated at the same time
  lazy var complete: (Lab) -> (String) = { lab in
    self.labs.append(lab)
    return "Great job \(self.labs.count) labs complete."
  }
  
  // var closure = self - strong reference
  // retain cycle or strong reference cycle
  // memory leaks
  // slow, crash 1 star , delete app
  
  func markComplete(lab: Lab) -> String {
    return complete(lab)
  }
}
